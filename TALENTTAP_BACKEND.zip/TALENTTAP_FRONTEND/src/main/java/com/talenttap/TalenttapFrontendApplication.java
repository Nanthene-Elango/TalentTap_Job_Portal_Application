package com.talenttap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TalenttapFrontendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TalenttapFrontendApplication.class, args);
	}

}
