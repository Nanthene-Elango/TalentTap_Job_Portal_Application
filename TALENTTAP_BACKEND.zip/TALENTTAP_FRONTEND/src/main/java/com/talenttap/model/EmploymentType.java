package com.talenttap.model;

import lombok.Data;

@Data
public class EmploymentType {
	private int employmentTypeId;
	private String employmentType;
}
