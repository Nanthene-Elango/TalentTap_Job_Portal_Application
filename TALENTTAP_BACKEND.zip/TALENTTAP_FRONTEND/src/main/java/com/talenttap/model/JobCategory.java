package com.talenttap.model;

import lombok.Data;

@Data
public class JobCategory {
	private int jobCategoryId;
	private String jobCategory;
}
