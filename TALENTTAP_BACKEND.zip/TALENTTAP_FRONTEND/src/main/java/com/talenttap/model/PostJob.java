package com.talenttap.model;

public class PostJob {
	private String jobRole;
	private int jobType;

}
