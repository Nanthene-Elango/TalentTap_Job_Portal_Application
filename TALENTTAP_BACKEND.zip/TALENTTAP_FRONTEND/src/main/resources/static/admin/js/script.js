// Check login status on page load (client-side check, server-side handled by Spring Security)
function checkLoginStatus() {
    if (sessionStorage.getItem('isLoggedIn') !== 'true') {
        window.location.href = '/login';
    }
}

// Logout function
function logout() {
    sessionStorage.removeItem('isLoggedIn');
    fetch('/api/logout', { 
        method: 'POST',
        credentials: 'include' // Include cookies for session
    })
        .then(response => {
            if (response.ok) {
                window.location.href = '/login';
            } else {
                console.error('Logout failed');
            }
        })
        .catch(error => console.error('Error during logout:', error));
}

// Sidebar Toggle for Mobile
document.getElementById('sidebarToggle').addEventListener('click', function() {
    document.getElementById('sidebar').classList.toggle('active');
});

// Section Toggle
function showSection(sectionId) {
    // Update sidebar navigation active state
    document.querySelectorAll('.sidebar .nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('data-section') === sectionId) {
            link.classList.add('active');
        }
    });

    // Update section title
    document.getElementById('section-title').textContent = sectionId.charAt(0).toUpperCase() + sectionId.slice(1) + ' Overview';

    // Show/hide sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
        section.style.display = 'none';
    });
    const sectionElement = document.getElementById(sectionId + 'Section');
    if (sectionElement) {
        sectionElement.classList.add('active');
        sectionElement.style.display = 'block';
    }
}

// Sidebar Navigation
document.querySelectorAll('.sidebar .nav-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        const sectionId = this.getAttribute('data-section');
        showSection(sectionId);
        window.location.hash = sectionId; // Update URL hash
    });
});

// Handle Hash on Page Load
document.addEventListener('DOMContentLoaded', function() {
    checkLoginStatus();
    const hash = window.location.hash.replace('#', '');
    const validSections = ['dashboard', 'jobs', 'employers', 'jobseekers', 'applications', 'settings'];
    if (hash && validSections.includes(hash)) {
        showSection(hash);
    } else {
        showSection('dashboard');
    }

    // Initialize charts
    initializeCharts();
});

// Jobs Section Functionality
const jobTable = document.getElementById('jobTable');
const statusFilter = document.getElementById('statusFilter');
const approvalFilter = document.getElementById('approvalFilter');
const employerSearch = document.getElementById('employerSearch');
const postedStartDate = document.getElementById('postedStartDate');
const postedEndDate = document.getElementById('postedEndDate');
const selectAllJobs = document.getElementById('selectAllJobs');
const bulkApprove = document.getElementById('bulkApprove');
const bulkReject = document.getElementById('bulkReject');

function filterJobs() {
    const status = statusFilter.value;
    const approval = approvalFilter.value;
    const search = employerSearch.value.toLowerCase();
    const startDate = postedStartDate.value;
    const endDate = postedEndDate.value;

    // Submit form to server for server-side filtering
    const form = statusFilter.closest('form');
    form.submit();
}

function updateBulkActions() {
    const selectedJobs = document.querySelectorAll('.job-select:checked');
    bulkApprove.disabled = selectedJobs.length === 0;
    bulkReject.disabled = selectedJobs.length === 0;
}

if (jobTable) {
    statusFilter.addEventListener('change', filterJobs);
    approvalFilter.addEventListener('change', filterJobs);
    employerSearch.addEventListener('input', filterJobs);
    postedStartDate.addEventListener('change', filterJobs);
    postedEndDate.addEventListener('change', filterJobs);

    selectAllJobs.addEventListener('change', function() {
        document.querySelectorAll('.job-select').forEach(checkbox => {
            checkbox.checked = this.checked;
        });
        updateBulkActions();
    });

    document.querySelectorAll('.job-select').forEach(checkbox => {
        checkbox.addEventListener('change', updateBulkActions);
    });

    bulkApprove.addEventListener('click', function() {
        const selectedIds = Array.from(document.querySelectorAll('.job-select:checked')).map(cb => cb.value);
        selectedIds.forEach(id => approveJob(id));
    });

    bulkReject.addEventListener('click', function() {
        const selectedIds = Array.from(document.querySelectorAll('.job-select:checked')).map(cb => cb.value);
        selectedIds.forEach(id => rejectJob(id));
    });
}

function approveJob(id) {
    fetch(`/api/jobs/${id}/approve`, { 
        method: 'POST',
        credentials: 'include'
    })
        .then(response => response.json())
        .then(data => {
            const row = document.querySelector(`tr[data-id='${id}']`);
            if (row) {
                row.cells[9].innerHTML = '<span class="badge bg-success">Approved</span>';
                filterJobs();
            }
        })
        .catch(error => console.error('Error approving job:', error));
}

function rejectJob(id) {
    fetch(`/api/jobs/${id}/reject`, { 
        method: 'POST',
        credentials: 'include'
    })
        .then(response => response.json())
        .then(data => {
            const row = document.querySelector(`tr[data-id='${id}']`);
            if (row) {
                row.cells[9].innerHTML = '<span class="badge bg-danger">Rejected</span>';
                filterJobs();
            }
        })
        .catch(error => console.error('Error rejecting job:', error));
}

function deleteJob(id) {
    if (confirm('Are you sure you want to delete this job?')) {
        fetch(`/api/jobs/${id}`, { 
            method: 'DELETE',
            credentials: 'include'
        })
            .then(response => {
                if (response.ok) {
                    const row = document.querySelector(`tr[data-id='${id}']`);
                    if (row) {
                        row.remove();
                        updateBulkActions();
                    }
                } else {
                    console.error('Error deleting job');
                }
            })
            .catch(error => console.error('Error deleting job:', error));
    }
}

// Employers Section Functionality
const employerTable = document.getElementById('employerTable');
const employerStatusFilter = document.getElementById('employerStatusFilter');
const industryFilter = document.getElementById('industryFilter');
const employerSearchInput = document.getElementById('employerSearch');
const employerStartDate = document.getElementById('postedStartDate');
const employerEndDate = document.getElementById('postedEndDate');
const selectAllEmployers = document.getElementById('selectAllEmployers');
const bulkApproveEmployers = document.getElementById('bulkApproveEmployers');
const bulkRejectEmployers = document.getElementById('bulkRejectEmployers');

function filterEmployers() {
    const status = employerStatusFilter.value;
    const industry = industryFilter.value;
    const search = employerSearchInput.value.toLowerCase();
    const startDate = employerStartDate.value;
    const endDate = employerEndDate.value;

    // Submit form to server for server-side filtering
    const form = employerStatusFilter.closest('form');
    form.submit();
}

function updateEmployerBulkActions() {
    const selectedEmployers = document.querySelectorAll('.employer-select:checked');
    bulkApproveEmployers.disabled = selectedEmployers.length === 0;
    bulkRejectEmployers.disabled = selectedEmployers.length === 0;
}

if (employerTable) {
    employerStatusFilter.addEventListener('change', filterEmployers);
    industryFilter.addEventListener('change', filterEmployers);
    employerSearchInput.addEventListener('input', filterEmployers);
    employerStartDate.addEventListener('change', filterEmployers);
    employerEndDate.addEventListener('change', filterEmployers);

    selectAllEmployers.addEventListener('change', function() {
        document.querySelectorAll('.employer-select').forEach(checkbox => {
            checkbox.checked = this.checked;
        });
        updateEmployerBulkActions();
    });

    document.querySelectorAll('.employer-select').forEach(checkbox => {
        checkbox.addEventListener('change', updateEmployerBulkActions);
    });

    bulkApproveEmployers.addEventListener('click', function() {
        const selectedIds = Array.from(document.querySelectorAll('.employer-select:checked')).map(cb => cb.value);
        selectedIds.forEach(id => approveEmployer(id));
    });

    bulkRejectEmployers.addEventListener('click', function() {
        const selectedIds = Array.from(document.querySelectorAll('.employer-select:checked')).map(cb => cb.value);
        selectedIds.forEach(id => rejectEmployer(id));
    });
}

function approveEmployer(id) {
    fetch(`/api/employers/${id}/approve`, { 
        method: 'POST',
        credentials: 'include'
    })
        .then(response => response.json())
        .then(data => {
            const row = document.querySelector(`tr[data-id='${id}']`);
            if (row) {
                row.cells[6].innerHTML = '<span class="badge bg-success">Approved</span>';
                filterEmployers();
            }
        })
        .catch(error => console.error('Error approving employer:', error));
}

function rejectEmployer(id) {
    fetch(`/api/employers/${id}/reject`, { 
        method: 'POST',
        credentials: 'include'
    })
        .then(response => response.json())
        .then(data => {
            const row = document.querySelector(`tr[data-id='${id}']`);
            if (row) {
                row.cells[6].innerHTML = '<span class="badge bg-danger">Rejected</span>';
                filterEmployers();
            }
        })
        .catch(error => console.error('Error rejecting employer:', error));
}

function deleteEmployer(id) {
    if (confirm('Are you sure you want to delete this employer?')) {
        fetch(`/api/employers/${id}`, { 
            method: 'DELETE',
            credentials: 'include'
        })
            .then(response => {
                if (response.ok) {
                    const row = document.querySelector(`tr[data-id='${id}']`);
                    if (row) {
                        row.remove();
                        updateEmployerBulkActions();
                    }
                } else {
                    console.error('Error deleting employer');
                }
            })
            .catch(error => console.error('Error deleting employer:', error));
    }
}

// Job Seekers Section Functionality
const seekerTable = document.getElementById('seekerTable');
const seekerStatusFilter = document.getElementById('seekerStatusFilter');
const locationFilter = document.getElementById('locationFilter');
const seekerSearchInput = document.getElementById('seekerSearch');
const seekerStartDate = document.getElementById('registeredStartDate');
const seekerEndDate = document.getElementById('registeredEndDate');
const selectAllSeekers = document.getElementById('selectAllSeekers');
const bulkActivateSeekers = document.getElementById('bulkActivateSeekers');
const bulkSuspendSeekers = document.getElementById('bulkSuspendSeekers');

function filterSeekers() {
    const status = seekerStatusFilter.value;
    const location = locationFilter.value;
    const search = seekerSearchInput.value.toLowerCase();
    const startDate = seekerStartDate.value;
    const endDate = seekerEndDate.value;

    // Submit form to server for server-side filtering
    const form = seekerStatusFilter.closest('form');
    form.submit();
}

function updateSeekerBulkActions() {
    const selectedSeekers = document.querySelectorAll('.seeker-select:checked');
    bulkActivateSeekers.disabled = selectedSeekers.length === 0;
    bulkSuspendSeekers.disabled = selectedSeekers.length === 0;
}

if (seekerTable) {
    seekerStatusFilter.addEventListener('change', filterSeekers);
    locationFilter.addEventListener('change', filterSeekers);
    seekerSearchInput.addEventListener('input', filterSeekers);
    seekerStartDate.addEventListener('change', filterSeekers);
    seekerEndDate.addEventListener('change', filterSeekers);

    selectAllSeekers.addEventListener('change', function() {
        document.querySelectorAll('.seeker-select').forEach(checkbox => {
            checkbox.checked = this.checked;
        });
        updateSeekerBulkActions();
    });

    document.querySelectorAll('.seeker-select').forEach(checkbox => {
        checkbox.addEventListener('change', updateSeekerBulkActions);
    });

    bulkActivateSeekers.addEventListener('click', function() {
        const selectedIds = Array.from(document.querySelectorAll('.seeker-select:checked')).map(cb => cb.value);
        selectedIds.forEach(id => toggleSeekerStatus(id, 'Active'));
    });

    bulkSuspendSeekers.addEventListener('click', function() {
        const selectedIds = Array.from(document.querySelectorAll('.seeker-select:checked')).map(cb => cb.value);
        selectedIds.forEach(id => toggleSeekerStatus(id, 'Suspended'));
    });
}

function toggleSeekerStatus(id, status) {
    fetch(`/api/jobseekers/${id}/status`, { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: status }),
        credentials: 'include'
    })
        .then(response => response.json())
        .then(data => {
            const row = document.querySelector(`tr[data-id='${id}']`);
            if (row) {
                row.cells[7].innerHTML = `<span class="badge bg-${status === 'Active' ? 'success' : 'danger'}">${status}</span>`;
                filterSeekers();
            }
        })
        .catch(error => console.error('Error toggling seeker status:', error));
}

// Sorting Functionality (Client-side sorting for tables)
function sortTable(tableId, columnIndex, isNumeric = false) {
    const table = document.getElementById(tableId);
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    const isAscending = table.dataset.sortDirection !== 'asc';

    rows.sort((a, b) => {
        let aValue = a.cells[columnIndex].textContent.trim();
        let bValue = b.cells[columnIndex].textContent.trim();

        if (isNumeric) {
            aValue = parseFloat(aValue) || 0;
            bValue = parseFloat(bValue) || 0;
        } else {
            aValue = aValue.toLowerCase();
            bValue = bValue.toLowerCase();
        }

        if (isAscending) {
            return aValue > bValue ? 1 : -1;
        } else {
            return aValue < bValue ? 1 : -1;
        }
    });

    table.dataset.sortDirection = isAscending ? 'asc' : 'desc';
    tbody.innerHTML = '';
    rows.forEach(row => tbody.appendChild(row));
}

// Add sorting listeners to table headers
function addSortingListeners(tableId, numericColumns = []) {
    const table = document.getElementById(tableId);
    if (table) {
        table.querySelectorAll('th').forEach((th, index) => {
            if (index !== 0 && index !== th.parentElement.cells.length - 1) { // Exclude checkbox and actions
                th.style.cursor = 'pointer';
                th.addEventListener('click', () => {
                    sortTable(tableId, index, numericColumns.includes(index));
                });
            }
        });
    }
}

addSortingListeners('jobTable', [5, 6, 7]); // Openings, Posted, Deadline
addSortingListeners('employerTable', [4, 5, 7]); // Jobs, Applications, Registered
addSortingListeners('seekerTable', [4, 5, 6]); // Experience, Applications, Registered

// Initialize Charts
function initializeCharts() {
    // User Growth Chart (Pie)
    const userGrowthChart = document.getElementById('userGrowthChart');
    if (userGrowthChart) {
        new Chart(userGrowthChart, {
            type: 'pie',
            data: {
                labels: ['Job Seekers', 'Employers'],
                datasets: [{
                    data: [750, 250], // Static data, can be fetched from /api/stats
                    backgroundColor: ['#5e17eb', '#2a0a5a'],
                    borderColor: ['#ffffff', '#ffffff'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: {
                            color: '#2a0a5a',
                            font: { family: 'Poppins', size: 12 }
                        }
                    }
                }
            }
        });
    }

    // Job Postings Chart (Bar)
    const jobPostingsChart = document.getElementById('jobPostingsChart');
    if (jobPostingsChart) {
        new Chart(jobPostingsChart, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Job Postings',
                    data: [50, 60, 45, 70, 55, 80],
                    backgroundColor: '#5e17eb',
                    borderColor: '#2a0a5a',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { ticks: { color: '#2a0a5a', font: { family: 'Poppins' } } },
                    y: { ticks: { color: '#2a0a5a', font: { family: 'Poppins' } } }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: '#2a0a5a',
                            font: { family: 'Poppins', size: 12 }
                        }
                    }
                }
            }
        });
    }

    // Job Applications Chart (Line)
    const jobApplicationsChart = document.getElementById('jobApplicationsChart');
    if (jobApplicationsChart) {
        new Chart(jobApplicationsChart, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Applications',
                    data: [200, 250, 180, 300, 220, 350],
                    borderColor: '#5e17eb',
                    backgroundColor: 'rgba(94, 23, 235, 0.2)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { ticks: { color: '#2a0a5a', font: { family: 'Poppins' } } },
                    y: { ticks: { color: '#2a0a5a', font: { family: 'Poppins' } } }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: '#2a0a5a',
                            font: { family: 'Poppins', size: 12 }
                        }
                    }
                }
            }
        });
    }

    // Recruiter Analytics Chart (Doughnut)
    const recruiterAnalyticsChart = document.getElementById('recruiterAnalyticsChart');
    if (recruiterAnalyticsChart) {
        new Chart(recruiterAnalyticsChart, {
            type: 'doughnut',
            data: {
                labels: ['Active', 'Inactive'],
                datasets: [{
                    data: [80, 20],
                    backgroundColor: ['#5e17eb', '#2a0a5a'],
                    borderColor: ['#ffffff', '#ffffff'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: {
                            color: '#2a0a5a',
                            font: { family: 'Poppins', size: 12 }
                        }
                    }
                }
            }
        });
    }
}