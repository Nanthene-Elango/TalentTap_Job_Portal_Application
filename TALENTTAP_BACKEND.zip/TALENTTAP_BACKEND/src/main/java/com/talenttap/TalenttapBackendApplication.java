package com.talenttap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TalenttapBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TalenttapBackendApplication.class, args);
	}

}
