package com.talenttap.entity;

public enum AuthProvider {

	MANUAL , GOOGLE
}
