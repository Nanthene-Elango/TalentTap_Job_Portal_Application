package com.talenttap.entity;

public enum WorkType {

	HYBRID,REMOTE,ONSITE
}
