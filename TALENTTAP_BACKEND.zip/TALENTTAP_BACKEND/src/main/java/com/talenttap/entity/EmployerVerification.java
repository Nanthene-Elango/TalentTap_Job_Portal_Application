package com.talenttap.entity;

public enum EmployerVerification {
	PENDING, APPROVED
}
