package com.talenttap.entity;

public enum ApplicationStatus {

	approved , pending , rejected
}
