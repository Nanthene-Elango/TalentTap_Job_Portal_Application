package com.talenttap.entity;

public enum JobStatus {
	open , closed , expired
}
