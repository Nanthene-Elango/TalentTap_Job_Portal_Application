package com.talenttap.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.talenttap.entity.EducationLevel;
public interface EducationLevelRepository extends JpaRepository<EducationLevel,Integer>{

}
