package com.talenttap.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.talenttap.entity.EmploymentType;

public interface EmploymentTypeRepository extends JpaRepository<EmploymentType,Integer>{

}
