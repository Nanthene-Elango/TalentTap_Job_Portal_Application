package com.talenttap.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.talenttap.entity.SalaryRange;

public interface SalaryRangeRepository  extends JpaRepository<SalaryRange,Integer>{

}
